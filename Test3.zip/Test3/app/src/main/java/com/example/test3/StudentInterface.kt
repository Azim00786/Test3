package com.example.test3

import java.text.FieldPosition

interface StudentInterface {

    fun onProfile(position: Int)
    fun next(position: Int)
}