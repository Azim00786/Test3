package com.example.test3

class MyData(
    val name: String,
    val description: String,
    val image: Int
)